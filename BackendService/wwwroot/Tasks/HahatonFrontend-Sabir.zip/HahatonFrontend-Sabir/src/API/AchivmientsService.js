
class AchievementsService {
    static f() {

    }

    static f1() {

    }
}