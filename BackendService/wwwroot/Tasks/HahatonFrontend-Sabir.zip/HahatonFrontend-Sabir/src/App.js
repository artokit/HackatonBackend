import {Routes, Route} from 'react-router-dom';
import Register from "./components/pages/Register/Register";
import Login from "./components/pages/Login/Login";
import Profile from "./components/pages/Profile/Profile";
import Achievements from "./components/pages/Achievements/Achievements";
import Editingtask from "./components/pages/Editingtask/Editingtask";
import Main from './components/pages/Main/Main';
import "./App.css";

function App() {
    return (
        <div id="app">

            <Routes>
                <Route exact path='/register' element={<Register text={"Регистрация"}/>}/>
                <Route exact path='/login' element={<Login text={"Вход"}/>}/>
                <Route exact path='/profile' element={<Profile />}/>
                <Route exact path='/tasks' element={<Register text={"Регистрация"}/>}/>
                <Route exact path='/edit' element={<Editingtask />}/>
                <Route exact path='/achievements' element={<Achievements/>}/>
                <Route exact path='/main' element={<Main/>}/>
            </Routes>

        </div>
    );
}

export default App;
