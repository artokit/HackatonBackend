import React from 'react';
import Wrapper from "../../Wrapper/Wrapper";
import classes from "./Achievements.module.css";


const Achievements = () => {
    return (
        <Wrapper>
            <div className={classes.adding_achiev}></div>
            <div className={classes.name_achiev}></div>
            <div className={classes.editor_achiev}>
                <div className={classes.achiev_row1}>
                    <div className={classes.achievements}></div>
                    <div className={classes.achievements}></div>
                    <div className={classes.achievements}></div>
                </div>
                <div className={classes.achiev_row2}>
                    <div className={classes.achievements}></div>
                    <div className={classes.achievements}></div>
                    <div className={classes.achievements}></div>
                </div>
            </div>
            
        </Wrapper>
    );
};

export default Achievements;