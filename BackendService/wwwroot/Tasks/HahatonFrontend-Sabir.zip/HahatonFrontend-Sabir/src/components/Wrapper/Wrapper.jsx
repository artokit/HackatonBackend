import React from 'react';
import Nav from "../shared/Nav/Nav";
import Header from "../shared/Header/Header";
import Footer from "../shared/Footer/Footer";
import cls from "./wrapper.module.css";

const Wrapper = ({children, ...props}) => {
    return (
        <div>
            <Header/>
            <div>
                <div style={{display: 'flex'}}>
                    <Nav/>
                    <div style={{width: '100%', height: 'calc(100vh - 120px)', overflow: 'auto'}} className={cls.bg}>
                        <div>{children}</div>
                        <Footer/>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Wrapper;