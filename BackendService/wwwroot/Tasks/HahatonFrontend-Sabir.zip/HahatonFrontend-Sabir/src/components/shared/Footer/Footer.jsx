import React from 'react';
import classes from './Footer.module.css';

const Footer = () => {
    return (
        <div>
            <div className={classes.about}>
                <div>о нас</div>
            </div>
            <div className={classes.footer}></div>
        </div>
    );
};

export default Footer;